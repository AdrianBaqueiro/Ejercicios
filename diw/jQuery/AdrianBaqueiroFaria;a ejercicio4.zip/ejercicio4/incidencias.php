﻿<?php
require("cabeceira.html");
// A librería de jQuery xa está cargada na cabeceira.
?>


<!-- Programar aquí o código de jQuery. -->




<?php 
    require("resto.html");
?>