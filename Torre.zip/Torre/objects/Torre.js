function Torre(nombre){
	this.nombre = nombre;
	this.fichas = [null];
	this.maxFichas = 3;
	this.setFicha = function(ficha){
		var fichaColocada=false;
		
		/* test 
		for(i=0;i<3;i++){
			if(this.fichas[i] == null)
			{
				this.fichas[i] = ficha;
				document.getElementById("mensaxes").innerHTML = "Ficha colocada en la posicion 0 de la "+this.nombre;
				console.log("Ficha colocada en la posicion 0 de la "+this.nombre+" ficha tama�o: "+ficha.getTama�o());
				fichaColocada=true;
				document.getElementById(this.nombre+"ficha"+(3-i)).style.width = ficha.getTama�o()+"px";
				document.getElementById(this.nombre+"ficha"+(3-i)).style.visibility = '';
				
			}
			
		}*/
		
		
		
		if(this.fichas[0] == null)
		{
			this.fichas[0] = ficha;
			document.getElementById("mensaxes").innerHTML = "Ficha colocada en la posicion 0 de la "+this.nombre;
			console.log("Ficha colocada en la posicion 0 de la "+this.nombre+" ficha tama�o: "+ficha.getTama�o());
			fichaColocada=true;
			document.getElementById(this.nombre+"ficha3").style.width = ficha.getTama�o()+"px";
			document.getElementById(this.nombre+"ficha3").style.visibility = '';
		}else
		{
			if(this.fichas[1]==null)
			{
				if(this.fichas[0].getTama�o() > ficha.getTama�o() )
				{
					this.fichas[1] = ficha;
					document.getElementById("mensaxes").innerHTML = "Ficha colocada en la posicion 1 de la "+this.nombre;
					console.log("Ficha colocada en la posicion 1 de la "+this.nombre+" ficha tama�o: "+ficha.getTama�o());
					fichaColocada=true;
					document.getElementById(this.nombre+"ficha2").style.width = ficha.getTama�o()+"px";
					document.getElementById(this.nombre+"ficha2").style.visibility = '';
				}
				
			}else
			{
				if(this.fichas[2]==null)
				{
					if(this.fichas[1].getTama�o() > ficha.getTama�o() )
					{
						this.fichas[2] = ficha;
						document.getElementById("mensaxes").innerHTML = "Ficha colocada en la posicion 2 de la "+this.nombre;
						console.log("Ficha colocada en la posicion 2 de la "+this.nombre+" ficha tama�o: "+ficha.getTama�o());
						fichaColocada=true;
						document.getElementById(this.nombre+"ficha1").style.width = ficha.getTama�o()+"px";
						document.getElementById(this.nombre+"ficha1").style.visibility = '';
					}
				}else
					document.getElementById("mensaxes").innerHTML = "No pode po�ela";
			}
		}
		return fichaColocada;
		
	}
	
	this.getFicha = function()
	{
		var aux;
		if(this.fichas[2]!=null)
		{
			console.log("Ficha quitada en la posicion 2 de la "+this.nombre+" FIcha: "+this.fichas[2].getTama�o());
			aux = this.fichas[2];
			this.fichas[2] = null;
			
			document.getElementById(this.nombre+"ficha1").style.visibility = 'hidden';
			return aux;
		}
		else
			if(this.fichas[1]!=null)
			{
				console.log("Ficha quitada en la posicion 1 de la "+this.nombre+" "+this.fichas[1].getTama�o());
				aux = this.fichas[1];
				this.fichas[1] = null;
				document.getElementById(this.nombre+"ficha2").style.visibility = 'hidden';
				return aux;
			}
			else
				if(this.fichas[0]!=null)
				{
					console.log("Ficha quitada en la posicion 0 de la "+this.nombre+" "+this.fichas[0].getTama�o());
					aux = this.fichas[0];
					this.fichas[0] = null;
					document.getElementById(this.nombre+"ficha3").style.visibility = 'hidden';
					return aux;
				}
	}
 }