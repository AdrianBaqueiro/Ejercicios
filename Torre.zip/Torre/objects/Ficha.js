function Ficha(tama�o)
{
	this.tama�o = tama�o;
	this.getTama�o = function(){return this.tama�o;};
}