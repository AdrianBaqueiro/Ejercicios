function Nube()
{
	this.ficha = null;
	this.getFicha = function(){
		console.log(this.ficha.getTama�o());
		var aux = this.ficha;
		this.ficha = null;
		this.hayFicha = false;
		document.getElementById("fichaNube").style.visibility = 'hidden';
		return aux;
	};
	this.setFicha = function(ficha){
		
		if(ficha!=null)
		{
			console.log(ficha.getTama�o());
			console.log(ficha);
			this.ficha=ficha;
			this.hayFicha=true;
			document.getElementById("fichaNube").style.width = ficha.getTama�o()+"px";
			document.getElementById("fichaNube").style.visibility = '';
		}
	};
	this.hayFichas = function(){
		return this.hayFicha;
	}
		
}