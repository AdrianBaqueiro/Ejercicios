var nube;
var fichaPeque�a;
var fichaMediana;
var fichaGrande;
var torre1;
var torre2;
var torre3;
var torres;
var nube;

window.onload = function(){
	fichaPeque�a = new Ficha(70);
	fichaMediana = new Ficha(120);
	fichaGrande = new Ficha(160);
	nube = new Nube();
	torre1 = new Torre("torre1");
	torre2 = new Torre("torre2");
	torre3 = new Torre("torre3");
	torres = [torre1,torre2,torre3];


	torre1.setFicha(fichaGrande);
	torre1.setFicha(fichaMediana);
	torre1.setFicha(fichaPeque�a);
}

function torre(posicion)
{
	
	if(nube.hayFicha === true)
	{
		var fichaAux = nube.getFicha();
		var fichaColocada = false;
		fichaColocada  = torres[posicion].setFicha(fichaAux);
		if(fichaColocada==false)
		{
			nube.setFicha(fichaAux);
			console.log("La ficha no puede colocarse ");
		}else
			console.log("ficha colocada ");
		
	}else
	{
		nube.setFicha(torres[posicion].getFicha());
	}
}

//document.getElementById("mensaxes").innerHTML = "asd";

  

 